function indexView(req, res){
    res.render("index.html", {});
}



module.exports =  {
    indexView,
};